#!/usr/bin/env python3
"""Creates charts and a before/after image from the benchmark output.

Usage (from the repository root, after running the benchmark):
    python3 scripts/plot_results.py

Inputs (whichever exist are used):
    output/benchmark_results.csv      main run, from ./run.sh
    results/radius_*.csv              radius sweep, from run_experiments.sh
    results/streams_*.csv             stream-count sweep
    output/input_image0.pgm and output/output_blurred_image0.pgm

Outputs go to the plots/ directory.
"""

import csv
import glob
import os
import re

import matplotlib
import numpy as np

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from PIL import Image  # noqa: E402

PLOT_DIR = "plots"


def read_csv(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def plot_main_results(csv_path):
    rows = read_csv(csv_path)
    names = [r["method"] for r in rows]
    total_ms = [float(r["total_ms"]) for r in rows]
    speedup = [float(r["speedup_vs_cpu"]) for r in rows]

    fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))
    axes[0].bar(names, total_ms, color="#4c72b0")
    axes[0].set_yscale("log")
    axes[0].set_ylabel("Total time for batch (ms, log scale)")
    axes[0].set_title("Total time")
    axes[1].bar(names, speedup, color="#55a868")
    axes[1].set_ylabel("Speedup vs CPU (x)")
    axes[1].set_title("Speedup")
    for ax in axes:
        ax.tick_params(axis="x", rotation=25)
    for i, value in enumerate(speedup):
        axes[1].text(i, value, f"{value:.1f}x", ha="center", va="bottom")
    first = rows[0]
    fig.suptitle(
        f"{first['num_images']} images of {first['width']}x{first['height']}, "
        f"radius {first['radius']}"
    )
    fig.tight_layout()
    out = os.path.join(PLOT_DIR, "main_results.png")
    fig.savefig(out, dpi=150)
    print("Wrote", out)


def plot_sweep(pattern, key_name, title, out_name, metric, ylabel,
               log_scale=False, methods=None):
    """Plots `metric` (a CSV column) per GPU method against the sweep value.

    GPU times are plotted instead of speedup versus the CPU because the CPU
    baseline timing varies from run to run on shared machines (e.g. Colab),
    which makes speedup charts misleading.
    """
    files = sorted(
        glob.glob(pattern),
        key=lambda p: int(re.search(r"_(\d+)\.csv$", p).group(1)),
    )
    if not files:
        return
    series = {}
    for path in files:
        key = int(re.search(r"_(\d+)\.csv$", path).group(1))
        for row in read_csv(path):
            if row["method"] == "cpu_single_thread":
                continue
            name = re.sub(r"_\d+$", "", row["method"])
            if methods and name not in methods:
                continue
            if row[metric] == "NA":
                continue
            series.setdefault(name, []).append((key, float(row[metric])))
    fig, ax = plt.subplots(figsize=(7, 4.5))
    for name, points in series.items():
        ax.plot([p[0] for p in points], [p[1] for p in points],
                marker="o", label=name)
    ax.set_xlabel(key_name)
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    if log_scale:
        ax.set_yscale("log")
    ax.set_xticks(sorted({p[0] for pts in series.values() for p in pts}))
    ax.legend()
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    out = os.path.join(PLOT_DIR, out_name)
    fig.savefig(out, dpi=150)
    print("Wrote", out)


def make_before_after(crop=512):
    """Saves original (left) and blurred (right) for the most detailed area."""
    before_path = "output/input_image0.pgm"
    after_path = "output/output_blurred_image0.pgm"
    if not (os.path.exists(before_path) and os.path.exists(after_path)):
        return
    before = Image.open(before_path)
    after = Image.open(after_path)
    width, height = before.size
    size = min(crop, width, height)
    # Pick the window with the largest variation in the blurred image, which
    # is the one containing the edge of the bright disc.
    blurred = np.asarray(after, dtype=np.float32)
    best_box, best_std = (0, 0, size, size), -1.0
    step = max(size // 4, 1)
    for top in range(0, height - size + 1, step):
        for left in range(0, width - size + 1, step):
            std = float(blurred[top:top + size, left:left + size].std())
            if std > best_std:
                best_std = std
                best_box = (left, top, left + size, top + size)
    canvas = Image.new("L", (size * 2 + 10, size), 255)
    canvas.paste(before.crop(best_box), (0, 0))
    canvas.paste(after.crop(best_box), (size + 10, 0))
    out = os.path.join(PLOT_DIR, "before_after_blur.png")
    canvas.save(out)
    print("Wrote", out, "(left: original, right: blurred)")


def main():
    os.makedirs(PLOT_DIR, exist_ok=True)
    main_csv = "output/benchmark_results.csv"
    if os.path.exists(main_csv):
        plot_main_results(main_csv)
    plot_sweep("results/radius_*.csv", "Filter radius",
               "Total time per image vs filter radius (incl. copies)",
               "sweep_radius_total.png", "ms_per_image",
               "GPU time per image (ms)", log_scale=True)
    plot_sweep("results/radius_*.csv", "Filter radius",
               "Kernel-only time: global vs shared memory",
               "sweep_radius_kernel.png", "kernel_ms",
               "Kernel time for batch (ms)", log_scale=True,
               methods=("cuda_global_memory", "cuda_shared_memory"))
    plot_sweep("results/streams_*.csv", "Number of streams",
               "Total time per image vs number of streams",
               "sweep_streams.png", "ms_per_image",
               "GPU time per image (ms)")
    make_before_after()


if __name__ == "__main__":
    main()
