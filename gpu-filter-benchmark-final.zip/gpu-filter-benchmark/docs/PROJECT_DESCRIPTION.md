# Project Description

## Goal
I wanted to understand why GPU programs get fast, not only that they do. I
took one operation, a 2D Gaussian blur on large images, and implemented it
four ways so that each technique from the course could be measured
separately: a CPU baseline, a global-memory CUDA kernel, a shared-memory
tiled kernel, and a streams-based version that overlaps data transfer with
computation. All experiments ran on a Tesla T4 GPU in Google Colab.

## What the program does
- Generates a batch of synthetic grayscale images (default: 20 images of
  2048x2048, about 84 million pixels) made of a gradient, a bright disc and
  noise.
- Blurs every image on the CPU (reference) and with three CUDA versions.
- Checks every GPU result against the CPU result. The maximum absolute
  difference is below 8e-5 (floating-point rounding only).
- Reports total time, kernel-only time, per-image time and speedup, and writes
  them to CSV. A command line interface controls batch size, image size,
  filter radius and number of streams.

## Kernels and techniques
1. **Global-memory kernel:** one thread per pixel; each thread reads its
   (2r+1)^2 neighbours directly from global memory.
2. **Shared-memory kernel:** each 16x16 block loads its tile plus a halo of r
   pixels into shared memory once, then threads read neighbours from on-chip
   memory. Borders are handled by clamping coordinates.
3. **Constant memory:** the filter weights are the same for every thread, so
   they live in constant memory.
4. **Pinned memory and streams:** images are distributed round-robin over N
   streams with `cudaMemcpyAsync`, so one image's copy overlaps another
   image's kernel.
5. **Timing:** CUDA events for kernel time and a wall-clock timer for
   end-to-end time. A warm-up run keeps one-time driver start-up cost out of
   the measurements.

## Results (Tesla T4, 20 images of 2048x2048, radius 3)
| Method                  | Total time | Speedup vs CPU |
|-------------------------|-----------:|---------------:|
| CPU single thread       | 6590 ms    | 1x             |
| CUDA global memory      | 80.2 ms    | 82x            |
| CUDA shared memory      | 80.3 ms    | 82x            |
| CUDA shared + 4 streams | 33.5 ms    | 197x           |

Experiments over filter radius (1, 3, 7, 15) and number of streams
(1, 2, 4, 8) are in `results/` and `plots/`.

## Lessons learned
**1. Shared memory only paid off at large filter sizes.** I expected the
shared-memory kernel to win everywhere. At radius 1, 3 and 7 the two kernels
ran in the same time (at radius 1 the shared version was about 10% slower
because loading the halo costs more than it saves). Only at radius 15 did
tiling win clearly: kernel time dropped from 182 ms to 77 ms, a 2.4x
improvement. My explanation is that the T4's L1/L2 caches already serve most
of the repeated neighbour reads at small radii, so manual tiling only helps
once each pixel is re-read many times (a 31x31 window means 961 reads per
output pixel).

**2. For small filters, moving data costs more than computing.** At radius 1
the kernels were only 11% of the total time; the rest was copying images
over PCIe (about 12.5 GB/s per direction measured). As the radius grew, the
kernel share rose to 33% (radius 3), 66% (radius 7) and 89% (radius 15). So
the same GPU code is "transfer-bound" or "compute-bound" depending on how
much work is done per pixel.

**3. Streams hide transfers, up to a limit.** With 1 stream there was no gain
over the sequential version (about 4.0 ms per image). With 2 streams it fell
to 2.2 ms and with 4 streams to 1.7 ms, and 8 streams gave no further
improvement. At that point the effective transfer rate was about 19.8 GB/s
(both directions together), close to what the PCIe link can deliver, so the
program is limited by the bus and not by the GPU. The benefit also shrank for
heavy filters (1.4x at radius 15) because overlap can only hide the smaller
of the transfer and compute times.

**4. A benchmarking pitfall: noisy baselines.** My first sweep chart plotted
speedup versus the CPU. The global and shared-memory lines jumped between
about 65x and 86x even though their GPU time did not change (about 64 ms
every run). The cause was the CPU reference, which varied from 4.2 s to 5.5 s
on the shared Colab machine. I changed the charts to compare absolute GPU
times, which gave a much clearer and more honest picture. The lesson is to be
careful about what a speedup number is relative to.

**Limitations and next steps.** The images are synthetic and everything ran
on one GPU, so absolute numbers will differ on other hardware. Kernel-only
time is not reported for the streams version because its work overlaps.
Next I would try a separable filter (two 1D passes, far fewer reads),
texture memory, the NPP library, real photographs, and profiling with Nsight
to confirm the PCIe bottleneck directly.

*[Optional: add a sentence or two about what was hardest for you personally
or what surprised you, in your own words.]*
